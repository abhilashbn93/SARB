use(function () {
    return {
        navRoot: pageManager.getPage('/content/geometrixx/en')
    };
});